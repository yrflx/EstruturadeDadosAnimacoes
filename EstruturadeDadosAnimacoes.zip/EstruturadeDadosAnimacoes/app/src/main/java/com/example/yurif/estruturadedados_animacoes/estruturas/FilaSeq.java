package com.example.yurif.estruturadedados_animacoes.estruturas;

/**
 * Created by yurif on 14/04/2018.
 */

public class FilaSeq {
    private int dados[];
    private int inicio;
    private int fim;

    private int nElementos;
    private int tamMax;

    public FilaSeq() {
        inicio = 0;
        fim = -1;
        nElementos = 0;

        tamMax = 100;
        dados =  new int[tamMax];
    }

    public FilaSeq(int n) {
        inicio = 0;
        fim = -1;
        nElementos = 0;

        tamMax = n;
        dados =  new int[tamMax];
    }

    /** Verifica se a Fila está vazia */
    public boolean vazia () {
        if (nElementos == 0)
            return true;
        else
            return false;
    }

    /**Verifica se a Fila está cheia */
    public boolean cheia () {
        if (nElementos == tamMax)
            return true;
        else
            return false;
    }

    /** Obtém o tamanho da Fila */
    public int tamanho() {
        return nElementos;
    }

    /** Consulta o elemento do início da fila.
     Retorna -1 se a fila estiver vazia. */
    public int primeiro() {
        if (vazia())
            return -1; // Erro: Fila vazia

        return dados[inicio];
    }

    /**Insere um elemento no fim de uma fila
     Retorna false se a fila estiver cheia, true caso contrário. */
    public boolean insere(int valor) {
        if (cheia()){
            return false;
        }

        fim++; // Circularidade
        dados[fim] = valor;
        nElementos++;
        return true;
    }

    /**Remove o elemento do início da fila e retorna o valor removido.
     Retorna -1 se a fila estiver vazia.*/
    public int remove() {
        if (vazia())
            return -1;

        int res = primeiro();
        inicio++; //Circularidade
        nElementos--;
        return res;
    }


    /** Obtém o i-ésimo elemento de uma lista.
     Retorna -1 se a posição for inválida. */
    public int elemento(int pos){

    	/* Se posição estiver fora dos limites <= 0
         * ou > tamanho da lista */
        if ((pos > fim + 1) || (pos <= 0))
            return -1;

        return dados[pos-1 + inicio];
    }

    /**	Retorna a posição de um elemento pesquisado.
     Retorna -1 caso não seja encontrado */
    public int posicao (int valor, int desloc){
		/* Procura elemento a elemento, se o dado está na
		lista. Se estiver, retorna a sua posição no array+1 */
        for (int i = desloc+1; i < fim+1; i++){
            if (dados[i] == valor){
                return (i + 1);
            }
        }

        return -1;
    }

    public String printar() {
        String elementos = "";
        for (int i = inicio; i <= fim; i++) {
            elementos += dados[i] + " - ";
        }

        return elementos;
    }



}
