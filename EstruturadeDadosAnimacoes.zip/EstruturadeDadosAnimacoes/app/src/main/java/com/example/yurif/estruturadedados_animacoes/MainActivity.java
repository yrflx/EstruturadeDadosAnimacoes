package com.example.yurif.estruturadedados_animacoes;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    public void abrirListaSeq(View view){
        startActivity(new Intent(this, ListaSequencial.class));
    }

    public void abrirLSE(View view){
        //startActivity(new Intent(this, LSE.class));
    }

    public void abrirPilha(View view){
      startActivity(new Intent(this, PilhaActivity.class));
    }

    public void abrirFila(View view){
        startActivity(new Intent(this, FilasActivity.class));
    }


}